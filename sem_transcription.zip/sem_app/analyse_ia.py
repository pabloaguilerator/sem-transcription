from export_documents import exporter_pdf, exporter_word
from chat_ia import preparar_fuentes, responder_pregunta
from gestion_reunions import cargar_analisis, guardar_analisis, cargar_reunion
from analisis_completo import generer_analyse_complete
import tkinter as tk
from tkinter import scrolledtext, ttk
import json
import threading
import urllib.request


def ouvrir_analyse(fenetre_parent, transcription, reunion_id=None):

    titre_reunion = "Réunion sans titre"
    date_reunion = ""

    if reunion_id:
        reunion = cargar_reunion(reunion_id)
        titre_reunion = reunion.get("titre") or titre_reunion
        date_reunion = reunion.get("date_enregistrement", "")

    datos_guardados = (
        cargar_analisis(reunion_id)
        if reunion_id else {'resume': '', 'historique': []}
    )
    historial_ia = list(datos_guardados['historique'])
    dialogue = tk.Toplevel(fenetre_parent)
    dialogue.title("SEM Transcription - Analyse avec l'IA")
    dialogue.geometry("1000x750")

    cadre = ttk.Frame(dialogue, padding=20)
    cadre.pack(fill=tk.BOTH, expand=True)

    ttk.Label(
        cadre,
        text="Analyse avec l'IA",
        font=("Arial", 20, "bold")
    ).pack(anchor="w", pady=(0, 15))

    ttk.Label(
        cadre,
        text="Résumé de la réunion",
        font=("Arial", 13, "bold")
    ).pack(anchor="w")

    zone_resume = scrolledtext.ScrolledText(
        cadre, height=12, wrap=tk.WORD
    )
    zone_resume.pack(fill=tk.BOTH, expand=True, pady=(5, 15))

    zone_resume.insert(
        tk.END,
        datos_guardados["resume"] or
        "Le résumé sera généré ici à partir de la transcription corrigée."
    )


    etat_resume = tk.StringVar(value="Prêt à générer le résumé.")

    # Sauvegarde automatique du résumé après deux secondes d'inactivité.
    sauvegarde_programmee = None

    def sauvegarder_resume():
        nonlocal sauvegarde_programmee
        sauvegarde_programmee = None

        if not reunion_id or not dialogue.winfo_exists():
            return

        try:
            guardar_analisis(
                reunion_id,
                zone_resume.get("1.0", "end-1c"),
                historial_ia
            )
        except Exception as error:
            etat_resume.set("Erreur de sauvegarde : " + str(error))

    def programmer_sauvegarde(event=None):
        nonlocal sauvegarde_programmee

        if not reunion_id:
            return

        if sauvegarde_programmee is not None:
            dialogue.after_cancel(sauvegarde_programmee)

        sauvegarde_programmee = dialogue.after(
            2000, sauvegarder_resume
        )

    zone_resume.bind("<<Modified>>", lambda event: (
        zone_resume.edit_modified(False),
        programmer_sauvegarde()
    ) if zone_resume.edit_modified() else None)

    def generer_resume():
        bouton_resume.config(state="disabled")
        etat_resume.set("Préparation de l'analyse...")

        def travail():
            try:
                def progression(message):
                    dialogue.after(
                        0,
                        lambda msg=message: (
                            etat_resume.set(msg)
                            if dialogue.winfo_exists() else None
                        )
                    )

                resume = generer_analyse_complete(
                    transcription,
                    progression=progression
                )

                def afficher():
                    if not dialogue.winfo_exists():
                        return
                    zone_resume.delete("1.0", tk.END)
                    zone_resume.insert(tk.END, resume)
                    etat_resume.set("Résumé généré avec succès.")
                    bouton_resume.config(state="normal")

                dialogue.after(0, afficher)

            except Exception as erreur:
                message_erreur = str(erreur)

                def afficher_erreur():
                    if not dialogue.winfo_exists():
                        return
                    etat_resume.set("Erreur : " + message_erreur)
                    bouton_resume.config(state="normal")

                dialogue.after(0, afficher_erreur)

        threading.Thread(target=travail, daemon=True).start()

    bouton_resume = ttk.Button(
        cadre,
        text="Générer le résumé",
        command=generer_resume
    )
    bouton_resume.pack(anchor="w", pady=(0, 5))

    def exportar_documento(formato):
        from tkinter import messagebox

        contenido = zone_resume.get("1.0", "end-1c").strip()
        placeholder = (
            "Le résumé sera généré ici à partir "
            "de la transcription corrigée."
        )

        if not contenido or contenido == placeholder:
            messagebox.showwarning(
                "Exportation",
                "Veuillez générer ou rédiger un résumé avant l'exportation.",
                parent=dialogue
            )
            return

        try:
            titre = "Résumé - " + titre_reunion

            if formato == "PDF":
                destination = exporter_pdf(titre, contenido, date_reunion)
            else:
                destination = exporter_word(titre, contenido, date_reunion)

            messagebox.showinfo(
                "Exportation réussie",
                "Document enregistré :\\n" + str(destination),
                parent=dialogue
            )

        except Exception as erreur:
            messagebox.showerror(
                "Erreur d'exportation",
                str(erreur),
                parent=dialogue
            )

    cadre_export = ttk.Frame(cadre)
    cadre_export.pack(anchor="w", pady=(5, 10))

    ttk.Button(
        cadre_export,
        text="Exporter en PDF",
        command=lambda: exportar_documento("PDF")
    ).pack(side=tk.LEFT, padx=(0, 10))

    ttk.Button(
        cadre_export,
        text="Exporter en Word",
        command=lambda: exportar_documento("Word")
    ).pack(side=tk.LEFT)


    ttk.Label(
        cadre,
        textvariable=etat_resume,
        foreground="gray"
    ).pack(anchor="w", pady=(0, 15))

    ttk.Label(
        cadre,
        text="Questions-réponses",
        font=("Arial", 13, "bold")
    ).pack(anchor="w")

    zone_chat = scrolledtext.ScrolledText(
        cadre, height=8, wrap=tk.WORD, state="disabled"
    )
    zone_chat.pack(fill=tk.BOTH, expand=True, pady=(5, 10))

    cadre_question = ttk.Frame(cadre)
    cadre_question.pack(fill=tk.X)

    champ_question = ttk.Entry(cadre_question)
    champ_question.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 10))


    fuentes_chat = preparar_fuentes(transcription)
    referencias_actuales = {}

    def escribir_chat(texto):
        zone_chat.config(state="normal")
        zone_chat.insert(tk.END, texto + "\n\n")
        zone_chat.see(tk.END)
        zone_chat.config(state="disabled")

    def ver_fuentes():
        if not referencias_actuales:
            return

        ventana_fuentes = tk.Toplevel(dialogue)
        ventana_fuentes.title("Sources de la réponse")
        ventana_fuentes.geometry("750x500")

        ttk.Label(
            ventana_fuentes,
            text="Extraits de la transcription",
            font=("Arial", 15, "bold")
        ).pack(anchor="w", padx=15, pady=15)

        texto_fuentes = scrolledtext.ScrolledText(
            ventana_fuentes, wrap=tk.WORD
        )
        texto_fuentes.pack(
            fill=tk.BOTH, expand=True, padx=15, pady=(0, 15)
        )

        for identificador, fragmento in referencias_actuales.items():
            texto_fuentes.insert(
                tk.END,
                "[" + identificador + "]\n" + fragmento + "\n\n"
            )

        texto_fuentes.config(state="disabled")

    def enviar_pregunta(event=None):
        pregunta = champ_question.get().strip()
        if not pregunta:
            return

        champ_question.delete(0, tk.END)
        bouton_envoyer.config(state="disabled")
        champ_question.config(state="disabled")
        escribir_chat("Vous : " + pregunta)
        escribir_chat("IA : Génération de la réponse en cours...")

        def trabajo():
            try:
                respuesta, referencias = responder_pregunta(
                    pregunta, fuentes_chat
                )
                resultado = ("ok", pregunta, respuesta, referencias)
            except Exception as error:
                resultado = ("error", pregunta, str(error), {})

            resultados_chat.put(resultado)

        threading.Thread(target=trabajo, daemon=True).start()

    import queue
    resultados_chat = queue.Queue()

    def comprobar_resultados():
        try:
            while True:
                estado, pregunta, respuesta, referencias = resultados_chat.get_nowait()

                zone_chat.config(state="normal")
                contenido = zone_chat.get("1.0", tk.END)
                marcador = "IA : Génération de la réponse en cours..."
                posicion = contenido.rfind(marcador)

                if posicion >= 0:
                    zone_chat.delete(
                        "1.0 + " + str(posicion) + " chars",
                        tk.END
                    )

                zone_chat.config(state="disabled")

                if estado == "ok":
                    escribir_chat("IA : " + respuesta)
                    historial_ia.append({
                        "question": pregunta,
                        "reponse": respuesta,
                        "sources": referencias
                    })
                    if reunion_id:
                        try:
                            guardar_analisis(
                                reunion_id,
                                zone_resume.get("1.0", "end-1c"),
                                historial_ia
                            )
                        except Exception as error:
                            etat_resume.set(
                                "Erreur de sauvegarde : " + str(error)
                            )
                    referencias_actuales.clear()
                    referencias_actuales.update(referencias)
                    boton_fuentes.config(
                        state="normal" if referencias else "disabled"
                    )
                else:
                    escribir_chat("Erreur : " + respuesta)

                bouton_envoyer.config(state="normal")
                champ_question.config(state="normal")
                champ_question.focus_set()

        except queue.Empty:
            pass

        if dialogue.winfo_exists():
            dialogue.after(200, comprobar_resultados)

    bouton_envoyer = ttk.Button(
        cadre_question,
        text="Envoyer",
        command=enviar_pregunta
    )
    bouton_envoyer.pack(side=tk.RIGHT)

    champ_question.bind("<Return>", enviar_pregunta)

    boton_fuentes = ttk.Button(
        cadre,
        text="Voir les sources",
        command=ver_fuentes,
        state="disabled"
    )
    boton_fuentes.pack(anchor="w", pady=(8, 5))

    # Restaurer les questions, réponses et sources enregistrées.
    for entrada in historial_ia:
        if not isinstance(entrada, dict):
            continue
        pregunta = entrada.get("question", "")
        respuesta = entrada.get("reponse", "")
        if isinstance(pregunta, str) and isinstance(respuesta, str):
            escribir_chat("Vous : " + pregunta)
            escribir_chat("IA : " + respuesta)

        fuentes = entrada.get("sources", {})
        if isinstance(fuentes, dict):
            referencias_actuales.clear()
            referencias_actuales.update(fuentes)

    boton_fuentes.config(
        state="normal" if referencias_actuales else "disabled"
    )

    dialogue.after(200, comprobar_resultados)


    ttk.Label(
        cadre,
        text="Assistant IA local - les réponses générées doivent être vérifiées",
        foreground="gray"
    ).pack(anchor="w", pady=(15, 0))

    def cerrar_analisis():
        if reunion_id:
            try:
                guardar_analisis(
                    reunion_id,
                    zone_resume.get("1.0", "end-1c"),
                    historial_ia
                )
            except Exception as error:
                from tkinter import messagebox
                messagebox.showerror(
                    "Erreur de sauvegarde",
                    str(error),
                    parent=dialogue
                )
                return
        else:
            from tkinter import messagebox
            confirmar = messagebox.askyesno(
                "Analyse non enregistrée",
                "Cette analyse n'est pas associée à une réunion "
                "enregistrée. En fermant cette fenêtre, son contenu "
                "sera perdu. Voulez-vous continuer ?",
                parent=dialogue
            )
            if not confirmar:
                return

        dialogue.destroy()

    dialogue.protocol("WM_DELETE_WINDOW", cerrar_analisis)

    return dialogue
