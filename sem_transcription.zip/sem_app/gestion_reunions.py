import json
import shutil
from datetime import datetime
from pathlib import Path
from uuid import uuid4

DOSSIER_REUNIONS = Path.home() / "projet_transcription/reunions"


def guardar_reunion(titulo, archivo_audio, transcripcion,
                   interlocutores=None, fragmentos=None, transcripcion_original=''):
    """Enregistre une réunion et ses fichiers localement."""
    audio = Path(archivo_audio)

    if not audio.is_file():
        raise FileNotFoundError(audio)

    if not transcripcion.strip():
        raise ValueError("La transcription est vide.")

    DOSSIER_REUNIONS.mkdir(parents=True, exist_ok=True)

    identificador = (
        datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        + "_" + uuid4().hex[:8]
    )

    carpeta = DOSSIER_REUNIONS / identificador
    carpeta.mkdir()

    try:
        destino_audio = carpeta / ("audio" + audio.suffix.lower())
        shutil.copy2(audio, destino_audio)

        (carpeta / "transcription.txt").write_text(
            transcripcion, encoding="utf-8"
        )

        datos = {
            "id": identificador,
            "titre": titulo.strip() or audio.stem,
            "date_enregistrement": datetime.now().isoformat(
                timespec="seconds"
            ),
            "audio": destino_audio.name,
            "transcription": "transcription.txt",
            "interlocuteurs": interlocutores or {},
            "fragments": fragmentos or [],
            "transcription_originale": transcripcion_original
        }

        (carpeta / "reunion.json").write_text(
            json.dumps(datos, ensure_ascii=False, indent=2),
            encoding="utf-8"
        )

    except Exception:
        shutil.rmtree(carpeta)
        raise

    return carpeta


def listar_reuniones():
    """Liste les réunions enregistrées."""
    if not DOSSIER_REUNIONS.exists():
        return []

    reuniones = []

    for archivo in DOSSIER_REUNIONS.glob("*/reunion.json"):
        try:
            datos = json.loads(archivo.read_text(encoding="utf-8"))
            reuniones.append(datos)
        except (OSError, ValueError):
            continue

    return sorted(
        reuniones,
        key=lambda reunion: reunion["date_enregistrement"],
        reverse=True
    )


def cargar_reunion(identificador):
    """Charge une réunion et sa transcription."""
    carpeta = DOSSIER_REUNIONS / identificador

    if not carpeta.is_dir() or carpeta.parent != DOSSIER_REUNIONS:
        raise ValueError("Réunion introuvable.")

    datos = json.loads(
        (carpeta / "reunion.json").read_text(encoding="utf-8")
    )

    datos["texte"] = (
        carpeta / datos["transcription"]
    ).read_text(encoding="utf-8")

    datos["chemin_audio"] = str(carpeta / datos["audio"])

    return datos


def _carpeta_analisis(identificador):
    """Localise une réunion existante sans accepter de chemin externe."""
    carpeta = DOSSIER_REUNIONS / identificador
    if (
        not isinstance(identificador, str)
        or not identificador
        or Path(identificador).name != identificador
        or not carpeta.is_dir()
        or not (carpeta / "reunion.json").is_file()
    ):
        raise ValueError("Réunion introuvable.")
    return carpeta


def guardar_analisis(identificador, resume, historique):
    """Enregistre le résumé et les questions-réponses localement."""
    carpeta = _carpeta_analisis(identificador)

    if not isinstance(resume, str) or not isinstance(historique, list):
        raise ValueError("Format d'analyse incorrect.")

    contenido = json.dumps(
        historique, ensure_ascii=False, indent=2
    )

    archivos = [
        (carpeta / "resume.txt", resume),
        (carpeta / "historique_ia.json", contenido),
    ]

    for destino, texto in archivos:
        temporal = destino.with_name(destino.name + ".tmp")
        temporal.write_text(texto, encoding="utf-8")
        temporal.replace(destino)


def cargar_analisis(identificador):
    """Récupère une analyse, y compris pour les anciennes réunions."""
    carpeta = _carpeta_analisis(identificador)
    ruta_resume = carpeta / "resume.txt"
    ruta_historique = carpeta / "historique_ia.json"

    resume = (
        ruta_resume.read_text(encoding="utf-8")
        if ruta_resume.exists() else ""
    )
    historique = (
        json.loads(ruta_historique.read_text(encoding="utf-8"))
        if ruta_historique.exists() else []
    )

    if not isinstance(historique, list):
        raise ValueError("Historique IA incorrect.")

    return {"resume": resume, "historique": historique}
