import subprocess
from pathlib import Path


class LecteurAudio:
    def __init__(self):
        self.processus = None

    def ecouter(self, fichier, debut, fin):
        self.arreter()

        fichier = Path(fichier)

        if not fichier.is_file():
            raise FileNotFoundError(fichier)

        duree = float(fin) - float(debut)

        if duree <= 0:
            raise ValueError("Durée du fragment invalide.")

        self.processus = subprocess.Popen(
            [
                "ffplay",
                "-nodisp",
                "-autoexit",
                "-loglevel", "error",
                "-ss", str(debut),
                "-t", str(duree),
                str(fichier)
            ],
            stdin=subprocess.DEVNULL
        )

    def arreter(self):
        if self.processus is not None:
            if self.processus.poll() is None:
                self.processus.terminate()
            self.processus = None


if __name__ == "__main__":
    fichier = (
        Path.home()
        / "projet_transcription/whisper.cpp/exp001_frances_1min.wav"
    )

    lecteur = LecteurAudio()
    lecteur.ecouter(fichier, 10, 15)

    print("Lecture de 10 à 15 secondes.")
    lecteur.processus.wait()
    print("Lecture terminée.")
