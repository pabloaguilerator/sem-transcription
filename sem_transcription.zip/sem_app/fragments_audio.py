import json
from pathlib import Path


def extraire_fragments(chemin_json):
    donnees = json.loads(
        Path(chemin_json).read_text(encoding="utf-8")
    )

    fragments = []

    for segment in donnees["transcription"]:
        texte = segment["text"].strip()

        if not texte:
            continue

        debut = segment["offsets"]["from"] / 1000
        fin = segment["offsets"]["to"] / 1000

        fragments.append({
            "debut": debut,
            "fin": fin,
            "texte": texte
        })

    return fragments


if __name__ == "__main__":
    exemple = {
        "transcription": [
            {
                "offsets": {"from": 12000, "to": 18000},
                "text": "Bonjour à tous."
            },
            {
                "offsets": {"from": 25000, "to": 30000},
                "text": "Merci beaucoup."
            }
        ]
    }

    import tempfile

    with tempfile.TemporaryDirectory() as dossier:
        archivo = Path(dossier) / "test.json"
        archivo.write_text(
            json.dumps(exemple),
            encoding="utf-8"
        )

        for fragment in extraire_fragments(archivo):
            print(fragment)
