import json
import re
import sys
from pathlib import Path


def lire_diarisation(chemin):
    segments = []
    motif = re.compile(
        r"([\d.]+)\s*-\s*([\d.]+)\s*\|\s*(SPEAKER_\d+)"
    )

    for ligne in Path(chemin).read_text(encoding="utf-8").splitlines():
        correspondance = motif.fullmatch(ligne.strip())

        if correspondance:
            debut, fin, locuteur = correspondance.groups()
            segments.append((float(debut), float(fin), locuteur))

    return segments


def choisir_locuteur(debut, fin, diarisation):
    scores = {}

    for debut_voix, fin_voix, locuteur in diarisation:
        chevauchement = max(
            0.0,
            min(fin, fin_voix) - max(debut, debut_voix)
        )

        scores[locuteur] = scores.get(locuteur, 0.0) + chevauchement

    if not scores or max(scores.values()) <= 0:
        return "Locuteur indéterminé"

    return max(scores, key=scores.get)


def fusionner(chemin_json, chemin_diarisation):
    donnees = json.loads(Path(chemin_json).read_text(encoding="utf-8"))
    diarisation = lire_diarisation(chemin_diarisation)

    lignes = []

    for segment in donnees["transcription"]:
        debut = segment["offsets"]["from"] / 1000
        fin = segment["offsets"]["to"] / 1000
        texte = segment["text"].strip()

        if not texte:
            continue

        locuteur = choisir_locuteur(debut, fin, diarisation)

        minutes, secondes = divmod(int(debut), 60)
        horodatage = f"{minutes:02d}:{secondes:02d}"

        lignes.append(f"{locuteur} [{horodatage}] : {texte}")

    return "\n\n".join(lignes)


if __name__ == "__main__":
    if len(sys.argv) != 4:
        print(
            "Usage : python fusion_locuteurs.py "
            "transcription.json diarisation.txt resultat.txt"
        )
        sys.exit(1)

    resultat = fusionner(sys.argv[1], sys.argv[2])
    Path(sys.argv[3]).write_text(resultat, encoding="utf-8")

    print("Fusion terminée.")
    print(f"Résultat : {sys.argv[3]}")
