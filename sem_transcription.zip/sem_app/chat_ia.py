import json
import re
import urllib.request

URL = "http" + chr(58) + chr(47) * 2 + "127.0.0.1:8080/v1/chat/completions"


def preparar_fuentes(transcripcion, max_caracteres=650):
    """Divide la transcripción en fragmentos con identificadores."""
    parrafos = [p.strip() for p in transcripcion.splitlines() if p.strip()]
    fuentes = []
    actual = ""

    for parrafo in parrafos:
        partes = [
            parrafo[i:i + max_caracteres]
            for i in range(0, len(parrafo), max_caracteres)
        ]

        for parte in partes:
            if actual and len(actual) + len(parte) + 1 > max_caracteres:
                fuentes.append(actual)
                actual = ""
            actual = (actual + "\n" + parte).strip()

    if actual:
        fuentes.append(actual)

    return {
        f"S{i}": texto
        for i, texto in enumerate(fuentes, start=1)
    }


def responder_pregunta(pregunta, fuentes):
    """Consulta Qwen3 y devuelve respuesta y fuentes verificadas."""
    contexto = "\n\n".join(
        f"[{identificador}]\n{texto}"
        for identificador, texto in fuentes.items()
    )

    instrucciones = (
        "Tu es un assistant d'analyse de réunions. "
        "Réponds en français uniquement à partir des extraits fournis. "
        "Cite les identifiants des extraits utilisés, par exemple [S1]. "
        "N'invente jamais de source. "
        "Si l'information est absente, indique-le clairement.\n\n"
        "EXTRAITS DE LA TRANSCRIPTION :\n"
        + contexto
        + "\n\nQUESTION :\n"
        + pregunta
    )

    donnees = {
        "messages": [{"role": "user", "content": instrucciones}],
        "max_tokens": 500,
        "temperature": 0.2
    }

    requete = urllib.request.Request(
        URL,
        data=json.dumps(donnees).encode("utf-8"),
        headers={"Content-Type": "application/json"}
    )

    with urllib.request.urlopen(requete, timeout=900) as reponse:
        resultat = json.load(reponse)

    texte = resultat["choices"][0]["message"]["content"] or ""

    references = list(dict.fromkeys(
        ref for ref in re.findall(r"\[(S\d+)\]", texte)
        if ref in fuentes
    ))

    return texte, {ref: fuentes[ref] for ref in references}
