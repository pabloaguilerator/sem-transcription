"""Analyse de transcriptions longues avec Qwen3 local."""


def diviser_transcription(texte, taille_max=1500):
    """Découpe une transcription en fragments sans perdre de texte."""
    if taille_max < 1:
        raise ValueError("La taille maximale doit être positive.")

    fragments = []
    lignes = texte.splitlines(keepends=True)
    courant = ""

    for ligne in lignes:
        if len(courant) + len(ligne) <= taille_max:
            courant += ligne
            continue

        if courant:
            fragments.append(courant)
            courant = ""

        while len(ligne) > taille_max:
            fragments.append(ligne[:taille_max])
            ligne = ligne[taille_max:]

        courant = ligne

    if courant:
        fragments.append(courant)

    return [
        {"id": f"S{i}", "texte": fragment}
        for i, fragment in enumerate(fragments, start=1)
    ]


def analyser_fragment(fragment, timeout=900, memoire=''):
    """Analyse un fragment avec Qwen3 local."""
    import json
    import urllib.request

    identifiant = fragment["id"]
    texte = fragment["texte"]

    contexte = (
        "CONTEXTE DES FRAGMENTS PRÉCÉDENTS :\n"
        + memoire.strip()
        + "\n\n"
        if memoire.strip() else ""
    )

    prompt = (
        "Tu analyses un fragment de transcription de réunion. "
        "Réponds uniquement en français et de manière concise.\n"
        "Identifie :\n"
        "1. Sujets abordés\n"
        "2. Propositions\n"
        "3. Décisions explicitement confirmées\n"
        "4. Actions, responsables et échéances\n"
        "5. Modifications ou rectifications des informations précédentes\n"
        "N'invente aucune information. "
        "Si un élément est absent, indique 'Non précisé'. "
        "Ne transforme pas une proposition en décision.\n\n"
        "Distingue explicitement ce qui est confirmé, ce qui reste à décider et ce qui est annulé ou rectifié. "
        "Si une date précédemment proposée est déclarée non confirmée, "
        "indique clairement que cette date reste à fixer. "

        "Utilise le contexte précédent uniquement pour comprendre "
        "les références et les changements de décision. "
        "N'attribue au fragment actuel que les informations "
        "présentes dans celui-ci.\n\n"
        + contexte
        + f"FRAGMENT ACTUEL {identifiant} :\n{texte}"
    )

    donnees = {
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": 450,
        "temperature": 0.1
    }

    requete = urllib.request.Request(
        "http://127.0.0.1:8080/v1/chat/completions",
        data=json.dumps(donnees).encode("utf-8"),
        headers={"Content-Type": "application/json"}
    )

    with urllib.request.urlopen(requete, timeout=timeout) as reponse:
        resultat = json.load(reponse)

    contenu = resultat["choices"][0]["message"]["content"]

    if not contenu.strip():
        raise RuntimeError(f"Réponse vide pour le fragment {identifiant}")

    return {
        "id": identifiant,
        "analyse": contenu,
        "usage": resultat.get("usage", {})
    }


def analyser_fragments_sequentiels(fragments, progression=None):
    """Analyse plusieurs fragments en conservant le contexte précédent."""
    resultats = []

    for numero, fragment in enumerate(fragments, start=1):
        memoire = construire_memoire_recente(
            resultats,
            limite=2500
        )
        if progression is not None:
            progression(numero, len(fragments), fragment["id"])

        resultat = analyser_fragment(
            fragment,
            memoire=memoire
        )

        resultats.append(resultat)

    return resultats


def construire_memoire_recente(resultats, limite=2500):
    """Construit un contexte récent sans dépasser une limite de caractères."""
    if limite < 1:
        raise ValueError("La limite doit être positive.")

    morceaux = []
    taille = 0

    for resultat in reversed(resultats):
        morceau = (
            f"FRAGMENT {resultat['id']} :\n"
            f"{resultat['analyse']}\n"
        )

        separateur = 1 if morceaux else 0

        if taille + separateur + len(morceau) > limite:
            if not morceaux:
                morceaux.insert(0, morceau[-limite:])
            break

        morceaux.insert(0, morceau)
        taille += separateur + len(morceau)

    return "\n".join(morceaux)


def creer_registre_reunion():
    """Crée un registre structuré des informations d'une réunion."""
    return {
        "sujets": [],
        "propositions": [],
        "decisions": [],
        "actions": [],
        "rectifications": []
    }


def ajouter_element_registre(registre, categorie, contenu, source):
    """Ajoute une information sans dupliquer son contenu."""
    if categorie not in registre:
        raise ValueError(f"Catégorie inconnue : {categorie}")

    contenu = contenu.strip()
    source = source.strip()

    if not contenu:
        raise ValueError("Le contenu ne peut pas être vide.")

    if not source:
        raise ValueError("La source ne peut pas être vide.")

    for element in registre[categorie]:
        if element["contenu"] == contenu:
            sources = element.setdefault(
                "sources", [element["source"]]
            )
            if source not in sources:
                sources.append(source)
            return element

    element = {
        "contenu": contenu,
        "source": source,
        "sources": [source]
    }

    registre[categorie].append(element)
    return element


def valider_extraction_structuree(extraction):
    """Valide les informations structurées d'un fragment."""
    categories = (
        "sujets",
        "propositions",
        "decisions",
        "actions",
        "rectifications"
    )

    if not isinstance(extraction, dict):
        raise ValueError("L'extraction doit être un dictionnaire.")

    if set(extraction) != set(categories):
        raise ValueError("Catégories manquantes ou inconnues.")

    for categorie in categories:
        elements = extraction[categorie]

        if not isinstance(elements, list):
            raise ValueError(
                f"La catégorie {categorie} doit être une liste."
            )

        for element in elements:
            if not isinstance(element, str) or not element.strip():
                raise ValueError(
                    f"Élément invalide dans {categorie}."
                )

    return True


def extraire_informations_structurees(fragment, timeout=900, memoire=''):
    """Extrait les informations d'un fragment au format JSON."""
    import json
    import urllib.request

    identifiant = fragment["id"]
    texte = fragment["texte"]

    prompt = (
        "Analyse cette transcription de réunion en français.\n"
        "Retourne uniquement un objet JSON valide avec exactement "
        "ces cinq clés : sujets, propositions, decisions, actions, "
        "rectifications.\n"
        "Chaque clé doit contenir une liste de chaînes de caractères.\n"
        "Utilise une liste vide si aucune information n'est présente.\n"
        "N'invente aucune information.\n"
        "DEFINITIONS STRICTES DES CATEGORIES :\n"
        "REGLE ABSOLUE : FIDELITE A LA TRANSCRIPTION.\n"
        "Utilise exclusivement les informations explicitement présentes dans le fragment actuel.\n"
        "N'ajoute aucune information issue de tes connaissances générales.\n"
        "Ne complète jamais une phrase avec une intention supposée.\n"
        "Ne déduis aucune décision, proposition ou action à partir d'un simple contexte.\n"
        "Une description, un témoignage ou une expérience passée ne sont pas des propositions.\n"
        "Une recherche déjà effectuée ne constitue pas une nouvelle action.\n"
        "La mention d'un article existant ne signifie pas qu'il faut en publier un.\n"
        "Une proposition doit correspondre à une solution concrète suggérée dans le fragment.\n"
        "Une solution peut être suggérée indirectement, mais elle doit être identifiable dans les paroles.\n"
        "Une décision exige une confirmation explicite des participants.\n"
        "Une action exige une tâche explicitement acceptée ou attribuée.\n"
        "N'invente jamais de responsable, de date ou d'échéance.\n"
        "En cas d'ambiguïté, n'ajoute pas l'information à la catégorie.\n"
        "Si aucune information fiable n'existe, retourne une liste vide.\n"
        "La fidélité au contenu est plus importante que le nombre d'éléments extraits.\n"
        "SUJETS : thèmes réellement abordés dans le fragment actuel.\n"
        "PROPOSITIONS : solutions, mesures ou initiatives explicitement suggérées.\n"
        "Une opinion, une question, une inquiétude ou un fait historique ne constitue pas une proposition.\n"
        "Une possibilité évoquée sans suggestion concrète ne constitue pas une proposition.\n"
        "DECISIONS : accords ou choix explicitement confirmés par les participants.\n"
        "ACTIONS : tâches concrètes explicitement attribuées ou acceptées.\n"
        "RECTIFICATIONS : corrections explicites d'informations précédentes.\n"
        "Ne transforme jamais un témoignage ou une description en proposition.\n"
        "En cas de doute, préfère une liste vide à une information non justifiée.\n"
        "Ne transforme jamais une proposition en décision.\n"
        "Conserve toutes les propositions, même non confirmées, "
        "notamment les dates, lieux et modalités envisagés.\n"
        "Une date proposée mais non confirmée reste une proposition, "
        "et non une décision ni une rectification.\n"
        "Une décision doit être explicitement confirmée.\n"
        "Conserve les noms, responsabilités et échéances mentionnés.\n"
        "Pour chaque action acceptée, indique explicitement le nom "
        "du responsable et l’échéance si elle est mentionnée.\n"
        "Une tâche explicitement acceptée doit figurer dans actions, "
        "et non être répétée dans propositions.\n"
        "Si le responsable est inconnu, ne l’invente pas.\n"
        "Distingue les rectifications des nouvelles décisions.\n"
        'RÈGLE PRIORITAIRE : extrais uniquement les faits exprimés dans le FRAGMENT ACTUEL.\n'
        'Le contexte précédent sert seulement à comprendre les références.\n'
        "N'extrais jamais les anciens faits comme des informations nouvelles.\n"
        'Une confirmation explicite doit figurer dans decisions.\n'
        'Une tâche acceptée doit figurer dans actions avec son responsable et son échéance.\n'
        "Ne crée pas de tâche supplémentaire à partir d'une simple expression d'accord.\n"
        "Ne répète pas une ancienne proposition si elle n'est pas reformulée.\n"
        'Une rectification doit préciser ce qui change en utilisant le contexte.\n'
        'Ne reproduis pas les informations sans rapport avec le fragment.\n'

        "CONTEXTE PRÉCÉDENT (pour comprendre les références, "
        "sans réextraire les anciens faits) :\n"
        f"{memoire}\n\n"
        f"FRAGMENT {identifiant} :\n{texte}"
    )

    donnees = {
        "messages": [
            {"role": "user", "content": prompt}
        ],
        "max_tokens": 700,
        "temperature": 0.1,
        "response_format": {"type": "json_object"}
    }

    requete = urllib.request.Request(
        "http://127.0.0.1:8080/v1/chat/completions",
        data=json.dumps(donnees).encode("utf-8"),
        headers={"Content-Type": "application/json"}
    )

    with urllib.request.urlopen(requete, timeout=timeout) as reponse:
        resultat = json.load(reponse)

    contenu = resultat["choices"][0]["message"]["content"]
    extraction = json.loads(contenu)

    valider_extraction_structuree(extraction)

    return {
        "id": identifiant,
        "extraction": extraction,
        "usage": resultat.get("usage", {})
    }


def integrer_extraction_registre(registre, resultat):
    """Ajoute une extraction structurée au registre de réunion."""
    identifiant = resultat["id"]
    extraction = resultat["extraction"]

    valider_extraction_structuree(extraction)

    for categorie, elements in extraction.items():
        for contenu in elements:
            ajouter_element_registre(
                registre,
                categorie,
                contenu,
                identifiant
            )

    return registre


def construire_registre_fragments(fragments, progression=None):
    """Construit un registre à partir de plusieurs fragments."""
    registre = creer_registre_reunion()
    resultats = []
    total = len(fragments)

    for numero, fragment in enumerate(fragments, start=1):
        if progression is not None:
            progression(numero, total, fragment["id"])

        memoire = construire_contexte_registre(
            registre,
            limite=2500
        )

        resultat = extraire_informations_structurees(
            fragment,
            memoire=memoire
        )

        integrer_extraction_registre(registre, resultat)
        resultats.append(resultat)

    return {
        "registre": registre,
        "resultats": resultats
    }


def construire_contexte_registre(registre, limite=2500):
    """Construit un contexte limité à partir du registre."""
    if limite < 1:
        raise ValueError("La limite doit être positive.")

    categories = (
        "rectifications",
        "decisions",
        "actions",
        "propositions",
        "sujets"
    )

    lignes = []

    for categorie in categories:
        for element in reversed(registre[categorie]):
            ligne = (
                f"[{element['source']}] "
                f"{categorie.upper()} : {element['contenu']}"
            )
            lignes.append(ligne)

    contexte = []
    taille = 0

    for ligne in lignes:
        separateur = 1 if contexte else 0

        if taille + separateur + len(ligne) > limite:
            continue

        contexte.append(ligne)
        taille += separateur + len(ligne)

    return "\n".join(contexte)
