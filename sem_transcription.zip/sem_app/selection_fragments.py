def identifier_fragment(texte, position):
    """
    Identifie l'intervention correspondant à une
    position dans le texte.
    """
    if position < 0 or position >= len(texte):
        return None

    debut = texte.rfind("\n\n", 0, position)
    debut = 0 if debut == -1 else debut + 2

    fin = texte.find("\n\n", position)
    fin = len(texte) if fin == -1 else fin

    intervention = texte[debut:fin]

    if not intervention.strip():
        return None

    index = texte[:debut].count("\n\n")

    return index


if __name__ == "__main__":
    exemple = (
        "Sophie [00:12] : Bonjour.\n\n"
        "Marc [00:25] : Merci.\n\n"
        "Sophie [00:38] : Très bien."
    )

    for mot in ["Bonjour", "Merci", "Très bien"]:
        position = exemple.index(mot)
        print(mot, "-> fragment", identifier_fragment(exemple, position))
