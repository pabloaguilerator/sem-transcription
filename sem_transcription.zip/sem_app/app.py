from analyse_ia import ouvrir_analyse

import tkinter as tk
from tkinter import messagebox, filedialog, scrolledtext, ttk
from pathlib import Path
import subprocess
import threading
import tempfile
import json
import time
import re
import os
import queue

from nombres_locutores import renombrar_interlocutores
from fragments_audio import extraire_fragments
from selection_fragments import identifier_fragment
from lecteur_audio import LecteurAudio
from gestion_reunions import guardar_reunion, listar_reuniones, cargar_reunion

BASE = Path.home() / "projet_transcription" / "whisper.cpp"
WHISPER = BASE / "build/bin/whisper-cli"
MODELE = BASE / "models/ggml-medium-q5_0.bin"

fichier_selectionne = None
reunion_actuelle_id = None
fragments_audio = []
lecteur_audio = LecteurAudio()
fragment_selectionne = None
transcription_actuelle = ""
traitement_en_cours = False
debut_transcription = None
progression_actuelle = 0
phase_traitement = "whisper"
evenements = queue.Queue()


def formater_temps(secondes):
    secondes = max(0, int(secondes))
    minutes, secondes = divmod(secondes, 60)
    heures, minutes = divmod(minutes, 60)

    if heures:
        return f"{heures:02d} h {minutes:02d} min {secondes:02d} s"
    return f"{minutes:02d} min {secondes:02d} s"


def analyser_audio(fichier):
    resultat = subprocess.run(
        [
            "ffprobe", "-v", "error",
            "-show_entries",
            "format=duration,size,format_name:"
            "stream=codec_type,sample_rate,channels",
            "-of", "json", str(fichier)
        ],
        capture_output=True,
        text=True,
        check=True
    )

    donnees = json.loads(resultat.stdout)
    fmt = donnees.get("format", {})
    pistes = [
        p for p in donnees.get("streams", [])
        if p.get("codec_type") == "audio"
    ]

    if not pistes:
        raise ValueError("Aucune piste audio détectée.")

    piste = pistes[0]
    duree = float(fmt.get("duration", 0))
    minutes, secondes = divmod(int(duree), 60)
    taille = int(fmt.get("size", 0)) / (1024 * 1024)

    return {
        "duree": f"{minutes:02d}:{secondes:02d}",
        "format": fmt.get("format_name", "Inconnu"),
        "taille": f"{taille:.2f} Mo",
        "frequence": f"{piste.get('sample_rate', '?')} Hz",
        "canaux": piste.get("channels", "?")
    }


def selectionner_audio():
    global reunion_actuelle_id
    global fichier_selectionne, transcription_actuelle
    global fragments_audio, fragment_selectionne
    global transcription_originale

    fichier = filedialog.askopenfilename(
        title="Sélectionner un fichier audio",
        filetypes=[
            ("Fichiers audio", "*.wav *.mp3 *.m4a *.flac *.wma"),
            ("Tous les fichiers", "*.*")
        ]
    )

    if not fichier:
        return

    try:
        donnees = analyser_audio(fichier)
        lecteur_audio.arreter()
        fragments_audio = []
        fragment_selectionne = None
        fichier_selectionne = Path(fichier)
        reunion_actuelle_id = None
        transcription_actuelle = ""
        transcription_originale = ""
        noms_interlocuteurs.clear()

        nom_fichier.config(text=fichier_selectionne.name)

        details.config(
            text=(
                f"Emplacement : {fichier_selectionne}\n"
                f"Durée : {donnees['duree']}\n"
                f"Format : {donnees['format']}\n"
                f"Taille : {donnees['taille']}\n"
                f"Fréquence : {donnees['frequence']}\n"
                f"Canaux : {donnees['canaux']}"
            )
        )

        zone_texte.delete("1.0", tk.END)
        barre["value"] = 0
        pourcentage.config(text="0 %")
        temps_ecoule.config(text="Temps écoulé : 00 min 00 s")
        temps_restant.config(text="Temps restant estimé : --")
        statut.config(text="Fichier prêt pour la transcription")

        bouton_transcrire.config(state="normal")
        bouton_enregistrer.config(state="disabled")

    except Exception as erreur:
        messagebox.showerror("Erreur", str(erreur))


def transcrire():
    global traitement_en_cours, debut_transcription
    global progression_actuelle, phase_traitement
    global fragments_audio, fragment_selectionne

    if fichier_selectionne is None or traitement_en_cours:
        return

    lecteur_audio.arreter()
    fragments_audio = []
    fragment_selectionne = None

    traitement_en_cours = True
    debut_transcription = None
    progression_actuelle = 0
    phase_traitement = "whisper"
    barre.stop()
    barre.config(mode="determinate")
    barre_diarisation.stop()
    barre_diarisation["value"] = 0
    etat_diarisation.config(text="En attente")

    barre["value"] = 0
    pourcentage.config(text="0 %")
    temps_ecoule.config(text="Temps écoulé : 00 min 00 s")
    temps_restant.config(text="Temps restant estimé : --")
    statut.config(text="Préparation du fichier audio...")

    bouton_selection.config(state="disabled")
    bouton_transcrire.config(state="disabled")
    bouton_enregistrer.config(state="disabled")

    threading.Thread(
        target=traitement_whisper,
        args=(fichier_selectionne,),
        daemon=True
    ).start()


def traitement_whisper(fichier):
    try:
        if not WHISPER.is_file():
            raise FileNotFoundError("Exécutable Whisper introuvable.")

        if not MODELE.is_file():
            raise FileNotFoundError("Modèle medium_Q5 introuvable.")

        with tempfile.TemporaryDirectory(
            prefix="sem_transcription_"
        ) as dossier:
            dossier = Path(dossier)
            audio_wav = dossier / "audio_16k.wav"
            sortie = dossier / "transcription"

            subprocess.run(
                [
                    "ffmpeg", "-nostdin", "-y",
                    "-v", "error",
                    "-i", str(fichier),
                    "-ar", "16000",
                    "-ac", "1",
                    "-c:a", "pcm_s16le",
                    str(audio_wav)
                ],
                check=True,
                capture_output=True,
                text=True
            )

            commande = [
                str(WHISPER),
                "-m", str(MODELE),
                "-f", str(audio_wav),
                "-l", "fr",
                "-otxt",
                "-oj",
                "-of", str(sortie),
                "--print-progress"
            ]

            # Évite la mise en mémoire tampon des sorties.
            environnement = os.environ.copy()
            environnement["GGML_LOG_LEVEL"] = "INFO"

            evenements.put(("demarrage", None))

            # Whisper écrit généralement sa progression
            # sur stderr. On fusionne les deux flux.
            processus = subprocess.Popen(
                commande,
                cwd=str(BASE),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                errors="replace",
                env=environnement
            )

            journal = []
            progression_max = 0

            # Lecture par caractères : accepte les lignes
            # terminées par \n ou par \r.
            tampon = ""

            while True:
                caractere = processus.stdout.read(1)

                if caractere == "":
                    if tampon:
                        journal.append(tampon)
                    break

                if caractere in ("\n", "\r"):
                    ligne = tampon.strip()
                    tampon = ""

                    if not ligne:
                        continue

                    journal.append(ligne)

                    # Exemple attendu :
                    # whisper_print_progress_callback: progress = 35%
                    correspondance = re.search(
                        r"progress\s*=\s*(\d{1,3})\s*%",
                        ligne,
                        flags=re.IGNORECASE
                    )

                    if correspondance:
                        valeur = min(
                            100, int(correspondance.group(1))
                        )
                        progression_max = max(
                            progression_max, valeur
                        )
                        evenements.put(
                            ("progression", progression_max)
                        )
                else:
                    tampon += caractere

            code_sortie = processus.wait()

            if code_sortie != 0:
                raise RuntimeError(
                    "Whisper a échoué.\n\n"
                    + "\n".join(journal[-12:])
                )

            fichier_txt = Path(str(sortie) + ".txt")

            if not fichier_txt.is_file():
                raise FileNotFoundError(
                    "Le fichier de transcription n'a pas été généré."
                )

            texte = fichier_txt.read_text(encoding="utf-8")

            # Deuxième étape : identification des interlocuteurs.
            evenements.put(("phase_diarisation", None))

            script_diarisation = (
                Path.home()
                / "projet_transcription/sem_app/diarisation_auto.py"
            )
            script_fusion = (
                Path.home()
                / "projet_transcription/sem_app/fusion_locuteurs.py"
            )
            python_pyannote = (
                Path.home()
                / "projet_transcription/venv_pyannote/bin/python"
            )

            fichier_json = Path(str(sortie) + ".json")
            fichier_diarisation = dossier / "diarisation.txt"
            fichier_fusion = dossier / "transcription_locuteurs.txt"

            try:
                if not fichier_json.is_file():
                    raise FileNotFoundError(
                        "Le fichier JSON de Whisper est introuvable."
                    )

                environnement_pyannote = os.environ.copy()
                environnement_pyannote["HF_HUB_OFFLINE"] = "1"

                subprocess.run(
                    [
                        str(python_pyannote),
                        str(script_diarisation),
                        str(audio_wav),
                        str(fichier_diarisation)
                    ],
                    check=True,
                    capture_output=True,
                    text=True,
                    env=environnement_pyannote
                )

                subprocess.run(
                    [
                        str(python_pyannote),
                        str(script_fusion),
                        str(fichier_json),
                        str(fichier_diarisation),
                        str(fichier_fusion)
                    ],
                    check=True,
                    capture_output=True,
                    text=True
                )

                texte = fichier_fusion.read_text(encoding="utf-8")

            except Exception as erreur_diarisation:
                evenements.put((
                    "avertissement_diarisation",
                    str(erreur_diarisation)
                ))

                evenements.put(("termine_sans_diarisation", texte))
            else:
                evenements.put(("termine", texte))

            # Conserver les temps des fragments avant
            # la suppression du dossier temporaire.
            try:
                fragments = extraire_fragments(fichier_json)
            except (OSError, ValueError, KeyError, TypeError):
                fragments = []

            evenements.put(("fragments_audio", fragments))

    except Exception as erreur:
        evenements.put(("erreur", str(erreur)))


def verifier_evenements():
    global fragments_audio
    global transcription_originale
    global debut_transcription, progression_actuelle
    global transcription_actuelle, traitement_en_cours
    global phase_traitement

    try:
        while True:
            type_evenement, valeur = evenements.get_nowait()

            if type_evenement == "demarrage":
                debut_transcription = time.monotonic()
                statut.config(text="Transcription en cours...")

            elif type_evenement == "progression":
                progression_actuelle = max(
                    progression_actuelle, valeur
                )
                barre["value"] = progression_actuelle
                pourcentage.config(
                    text=f"{progression_actuelle} %"
                )

            elif type_evenement == "fragments_audio":
                fragments_audio = valeur

            elif type_evenement == "phase_diarisation":
                phase_traitement = "diarisation"
                statut.config(
                    text="Identification des interlocuteurs en cours..."
                )
                barre["value"] = 100
                pourcentage.config(text="100 %")
                barre_diarisation.start(12)
                etat_diarisation.config(text="En cours...")
                temps_restant.config(
                    text="Temps restant estimé : indisponible"
                )

            elif type_evenement == "avertissement_diarisation":
                statut.config(
                    text="Diarisation indisponible : transcription conservée"
                )
                print("Avertissement diarisation :", valeur)

            elif type_evenement in ("termine", "termine_sans_diarisation"):
                barre.stop()
                barre_diarisation.stop()
                etat_diarisation.config(
                    text="Terminé" if type_evenement == "termine"
                    else "Indisponible"
                )
                barre.config(mode="determinate")
                traitement_en_cours = False
                transcription_actuelle = valeur
                transcription_originale = valeur
                noms_interlocuteurs.clear()

                zone_texte.delete("1.0", tk.END)
                zone_texte.insert(tk.END, valeur)

                barre["value"] = 100
                pourcentage.config(text="100 %")
                statut.config(
                    text="Transcription terminée"
                    if type_evenement == "termine"
                    else "Transcription terminée sans identification des interlocuteurs"
                )
                temps_restant.config(
                    text="Temps restant estimé : 00 min 00 s"
                )

                bouton_selection.config(state="normal")
                bouton_transcrire.config(state="normal")
                bouton_enregistrer.config(state="normal")

            elif type_evenement == "erreur":
                barre.stop()
                barre_diarisation.stop()
                etat_diarisation.config(text="Interrompu")
                barre.config(mode="determinate")
                traitement_en_cours = False
                statut.config(text="Erreur de transcription")

                bouton_selection.config(state="normal")
                bouton_transcrire.config(state="normal")

                messagebox.showerror(
                    "Erreur de transcription", valeur
                )

    except queue.Empty:
        pass

    if debut_transcription is not None and traitement_en_cours:
        ecoule = time.monotonic() - debut_transcription
        temps_ecoule.config(
            text=f"Temps écoulé : {formater_temps(ecoule)}"
        )

        if (
            traitement_en_cours
            and phase_traitement == "whisper"
            and 0 < progression_actuelle < 100
        ):
            estimation = (
                ecoule * (100 - progression_actuelle)
                / progression_actuelle
            )
            temps_restant.config(
                text=(
                    "Temps restant estimé : "
                    + formater_temps(estimation)
                )
            )
        elif (
            traitement_en_cours
            and phase_traitement == "whisper"
            and progression_actuelle == 0
        ):
            temps_restant.config(
                text="Temps restant estimé : calcul en cours..."
            )

    fenetre.after(500, verifier_evenements)




# Noms personnalisés des interlocuteurs
transcription_originale = ""
noms_interlocuteurs = {}


def ouvrir_fenetre_interlocuteurs():
    global transcription_actuelle

    if not transcription_originale:
        messagebox.showinfo(
            "Information",
            "Aucune transcription disponible."
        )
        return

    identifiants = sorted(set(re.findall(
        r"(?m)^(SPEAKER_\d+)(?=\s+\[\d{2}:\d{2}\]\s*:)",
        transcription_originale
    )))

    if not identifiants:
        messagebox.showinfo(
            "Information",
            "Aucun interlocuteur identifié."
        )
        return

    dialogue = tk.Toplevel(fenetre)
    dialogue.title("Renommer les interlocuteurs")
    dialogue.geometry("420x300")
    dialogue.transient(fenetre)
    dialogue.grab_set()

    tk.Label(
        dialogue,
        text="Attribuer un nom à chaque interlocuteur",
        font=("Arial", 12, "bold")
    ).pack(pady=15)

    champs = {}

    for identifiant in identifiants:
        ligne = tk.Frame(dialogue)
        ligne.pack(fill="x", padx=20, pady=5)

        tk.Label(
            ligne,
            text=identifiant,
            width=15,
            anchor="w"
        ).pack(side="left")

        champ = tk.Entry(ligne)
        champ.pack(side="left", fill="x", expand=True)
        champ.insert(
            0,
            noms_interlocuteurs.get(identifiant, "")
        )
        champs[identifiant] = champ

    def appliquer():
        global transcription_actuelle

        noms_interlocuteurs.clear()

        for identifiant, champ in champs.items():
            nom = champ.get().strip()
            if nom:
                noms_interlocuteurs[identifiant] = nom

        transcription_actuelle = renombrar_interlocutores(
            transcription_originale,
            noms_interlocuteurs
        )

        zone_texte.delete("1.0", tk.END)
        zone_texte.insert(tk.END, transcription_actuelle)

        dialogue.destroy()

    tk.Button(
        dialogue,
        text="Appliquer les noms",
        command=appliquer,
        padx=15,
        pady=8
    ).pack(pady=20)




def passer_analyse_ia():
    texte = zone_texte.get("1.0", "end-1c")
    if not texte.strip():
        messagebox.showinfo(
            "Information",
            "Aucune transcription disponible pour l'analyse."
        )
        return
    ouvrir_analyse(fenetre, texte, reunion_actuelle_id)


def enregistrer_reunion():
    global reunion_actuelle_id
    if fichier_selectionne is None:
        messagebox.showinfo(
            "Information",
            "Veuillez sélectionner un fichier audio."
        )
        return

    texte_corrige = zone_texte.get("1.0", "end-1c")

    if not texte_corrige.strip():
        messagebox.showinfo(
            "Information",
            "Aucune transcription disponible."
        )
        return

    from tkinter import simpledialog

    titre = simpledialog.askstring(
        "Enregistrer la réunion",
        "Titre de la réunion :",
        initialvalue=fichier_selectionne.stem,
        parent=fenetre
    )

    if titre is None:
        return

    try:
        carpeta = guardar_reunion(
            titulo=titre,
            archivo_audio=fichier_selectionne,
            transcripcion=texte_corrige,
            interlocutores=noms_interlocuteurs.copy(),
            fragmentos=fragments_audio.copy(),
            transcripcion_original=transcription_originale
        )

        reunion_actuelle_id = carpeta.name

        messagebox.showinfo(
            "Réunion enregistrée",
            "La réunion a été enregistrée avec succès.\\n"
            + str(carpeta)
        )

    except Exception as erreur:
        messagebox.showerror(
            "Erreur d'enregistrement",
            str(erreur)
        )


def enregistrer_transcription():
    texte_corrige = zone_texte.get("1.0", "end-1c")
    if not texte_corrige.strip():
        return

    dossier = Path.home() / "Downloads"
    dossier.mkdir(parents=True, exist_ok=True)

    nom = (
        fichier_selectionne.stem + "_transcription.txt"
        if fichier_selectionne else "transcription.txt"
    )
    destination = dossier / nom

    if destination.exists():
        confirmer = messagebox.askyesno(
            "Fichier existant",
            "Ce fichier existe déjà. Voulez-vous le remplacer ?"
        )
        if not confirmer:
            return

    try:
        destination.write_text(
            texte_corrige, encoding="utf-8"
        )
        messagebox.showinfo(
            "Enregistrement terminé",
            f"Transcription enregistrée dans :\n{destination}"
        )
    except OSError as erreur:
        messagebox.showerror(
            "Erreur d'enregistrement", str(erreur)
        )


# Interface graphique
fenetre = tk.Tk()
fenetre.title("SEM Transcription")
fenetre.geometry("850x780")
fenetre.minsize(700, 650)

# Conteneur principal avec défilement vertical
conteneur = tk.Frame(fenetre)
conteneur.pack(fill=tk.BOTH, expand=True)

canvas = tk.Canvas(conteneur, highlightthickness=0)
scrollbar = ttk.Scrollbar(
    conteneur, orient="vertical", command=canvas.yview
)
canvas.configure(yscrollcommand=scrollbar.set)

scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

contenu = tk.Frame(canvas)
fenetre_contenu = canvas.create_window(
    (0, 0), window=contenu, anchor="nw"
)

def actualiser_defilement(event=None):
    canvas.configure(scrollregion=canvas.bbox("all"))

def ajuster_largeur(event):
    canvas.itemconfigure(fenetre_contenu, width=event.width)

contenu.bind("<Configure>", actualiser_defilement)
canvas.bind("<Configure>", ajuster_largeur)


tk.Label(
    contenu,
    text="SEM Transcription",
    font=("Arial", 22, "bold")
).pack(pady=(15, 5))

tk.Label(
    contenu,
    text="Transcription automatique de fichiers audio",
    font=("Arial", 11)
).pack(pady=5)

def ouvrir_bibliotheque():
    ventana = tk.Toplevel(fenetre)
    ventana.title("Mes réunions - SEM Transcription")
    ventana.geometry("650x450")
    ventana.minsize(450, 300)

    tk.Label(
        ventana,
        text="Mes réunions",
        font=("Arial", 18, "bold")
    ).pack(pady=(20, 5))

    tk.Label(
        ventana,
        text="Réunions enregistrées sur cet appareil"
    ).pack(pady=(0, 15))

    cadre_liste = tk.Frame(ventana)
    cadre_liste.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)

    liste = tk.Listbox(
        cadre_liste,
        font=("Arial", 11),
        selectmode=tk.SINGLE
    )
    liste.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

    defilement = ttk.Scrollbar(
        cadre_liste,
        orient="vertical",
        command=liste.yview
    )
    defilement.pack(side=tk.RIGHT, fill=tk.Y)
    liste.config(yscrollcommand=defilement.set)

    try:
        reunions = listar_reuniones()
    except Exception as erreur:
        messagebox.showerror("Erreur", str(erreur), parent=ventana)
        ventana.destroy()
        return

    for reunion in reunions:
        date = reunion.get("date_enregistrement", "")[:16]
        date = date.replace("T", " ")
        titre = reunion.get("titre", "Sans titre")
        liste.insert(tk.END, f"{date}  |  {titre}")

    if not reunions:
        liste.insert(tk.END, "Aucune réunion enregistrée.")

    def ouvrir_reunion_selectionnee():
        global fichier_selectionne, transcription_actuelle
        global transcription_originale, fragments_audio
        global fragment_selectionne
        global reunion_actuelle_id

        selection = liste.curselection()

        if not selection or not reunions:
            messagebox.showinfo(
                "Mes réunions",
                "Veuillez sélectionner une réunion.",
                parent=ventana
            )
            return

        if traitement_en_cours:
            messagebox.showwarning(
                "Transcription en cours",
                "Attendez la fin du traitement.",
                parent=ventana
            )
            return

        try:
            reunion = cargar_reunion(
                reunions[selection[0]]["id"]
            )
            audio = Path(reunion["chemin_audio"])
            donnees = analyser_audio(audio)
            texte = reunion["texte"]

            if not audio.is_file():
                raise FileNotFoundError(audio)

        except Exception as erreur:
            messagebox.showerror(
                "Erreur d'ouverture",
                str(erreur),
                parent=ventana
            )
            return

        lecteur_audio.arreter()

        fichier_selectionne = audio
        reunion_actuelle_id = reunion["id"]
        transcription_actuelle = texte
        transcription_originale = reunion.get(
            "transcription_originale"
        ) or texte

        noms_interlocuteurs.clear()
        noms_interlocuteurs.update(
            reunion.get("interlocuteurs") or {}
        )

        fragments_audio = reunion.get("fragments") or []
        fragment_selectionne = None

        nom_fichier.config(
            text=reunion.get("titre", audio.name)
        )
        details.config(
            text=(
                f"Emplacement : {audio}\\n"
                f"Durée : {donnees['duree']}\\n"
                f"Format : {donnees['format']}\\n"
                f"Taille : {donnees['taille']}\\n"
                f"Fréquence : {donnees['frequence']}\\n"
                f"Canaux : {donnees['canaux']}"
            )
        )

        zone_texte.delete("1.0", tk.END)
        zone_texte.insert("1.0", texte)

        barre["value"] = 100
        pourcentage.config(text="100 %")
        barre_diarisation.stop()
        etat_diarisation.config(text="Terminé")
        statut.config(text="Réunion chargée")
        temps_restant.config(
            text="Temps restant estimé : --"
        )

        bouton_transcrire.config(state="normal")
        bouton_enregistrer.config(state="normal")

        ventana.destroy()

    cadre_actions = tk.Frame(ventana)
    cadre_actions.pack(pady=(5, 15))

    tk.Button(
        cadre_actions,
        text="Ouvrir la réunion",
        command=ouvrir_reunion_selectionnee,
        padx=15,
        pady=8
    ).pack(side=tk.LEFT, padx=5)

    tk.Button(
        cadre_actions,
        text="Fermer",
        command=ventana.destroy,
        padx=20,
        pady=8
    ).pack(side=tk.LEFT, padx=5)


cadre_selection = tk.Frame(contenu)
cadre_selection.pack(pady=10)

bouton_selection = tk.Button(
    cadre_selection,
    text="Sélectionner un fichier audio",
    command=selectionner_audio,
    font=("Arial", 12),
    padx=12,
    pady=8
)
bouton_selection.pack(side=tk.LEFT, padx=5)

bouton_bibliotheque = tk.Button(
    cadre_selection,
    text="Mes réunions",
    command=ouvrir_bibliotheque,
    font=("Arial", 12),
    padx=12,
    pady=8
)
bouton_bibliotheque.pack(side=tk.LEFT, padx=5)

nom_fichier = tk.Label(
    contenu,
    text="Aucun fichier sélectionné",
    font=("Arial", 12, "bold")
)
nom_fichier.pack(pady=5)

details = tk.Label(
    contenu,
    text="Sélectionnez un fichier pour afficher ses caractéristiques.",
    justify="left",
    wraplength=750
)
details.pack(pady=8)

bouton_transcrire = tk.Button(
    contenu,
    text="Transcrire le fichier",
    command=transcrire,
    font=("Arial", 12, "bold"),
    state="disabled",
    padx=15, pady=8
)
bouton_transcrire.pack(pady=10)

statut = tk.Label(
    contenu,
    text="En attente d'un fichier audio...",
    fg="blue"
)
statut.pack(pady=5)

# Étape 1 : transcription audio
tk.Label(
    contenu,
    text="1. Transcription audio",
    font=("Arial", 11, "bold"),
    anchor="w"
).pack(fill="x", padx=25, pady=(10, 3))

cadre_progression = tk.Frame(contenu)
cadre_progression.pack(fill="x", padx=25, pady=3)

barre = ttk.Progressbar(
    cadre_progression,
    orient="horizontal",
    mode="determinate",
    maximum=100
)
barre.pack(side="left", fill="x", expand=True)

pourcentage = tk.Label(
    cadre_progression,
    text="0 %",
    width=12,
    font=("Arial", 10)
)
pourcentage.pack(side="right", padx=(10, 0))

# Étape 2 : identification des interlocuteurs
tk.Label(
    contenu,
    text="2. Identification des interlocuteurs",
    font=("Arial", 11, "bold"),
    anchor="w"
).pack(fill="x", padx=25, pady=(10, 3))

cadre_diarisation = tk.Frame(contenu)
cadre_diarisation.pack(fill="x", padx=25, pady=3)

barre_diarisation = ttk.Progressbar(
    cadre_diarisation,
    orient="horizontal",
    mode="indeterminate",
    maximum=100
)
barre_diarisation.pack(side="left", fill="x", expand=True)

etat_diarisation = tk.Label(
    cadre_diarisation,
    text="En attente",
    width=12,
    font=("Arial", 10)
)
etat_diarisation.pack(side="right", padx=(10, 0))

temps_ecoule = tk.Label(
    contenu,
    text="Temps écoulé : 00 min 00 s"
)
temps_ecoule.pack(pady=2)

temps_restant = tk.Label(
    contenu,
    text="Temps restant estimé : --"
)
temps_restant.pack(pady=2)

tk.Label(
    contenu,
    text="Résultat de la transcription",
    font=("Arial", 13, "bold")
).pack(pady=(12, 5))

def selectionner_fragment(event):
    global fragment_selectionne
    if not fragments_audio:
        return

    position = zone_texte.index(f"@{event.x},{event.y}")
    texte = zone_texte.get("1.0", "end-1c")
    caracteres = len(zone_texte.get("1.0", position))

    index = identifier_fragment(texte, caracteres)

    if index is None or index >= len(fragments_audio):
        return

    fragment_selectionne = index
    fragment = fragments_audio[index]

    print(
        f"Fragment {index + 1} : "
        f"{fragment['debut']:.2f}s - {fragment['fin']:.2f}s",
        flush=True
    )


def ecouter_fragment():
    if (
        fragment_selectionne is None
        or fragment_selectionne >= len(fragments_audio)
        or fichier_selectionne is None
    ):
        messagebox.showinfo(
            "Lecture audio",
            "Sélectionnez d'abord une intervention."
        )
        return

    fragment = fragments_audio[fragment_selectionne]

    try:
        lecteur_audio.ecouter(
            fichier_selectionne,
            fragment["debut"],
            fragment["fin"]
        )
    except Exception as erreur:
        messagebox.showerror("Lecture audio", str(erreur))


def arreter_fragment():
    lecteur_audio.arreter()


zone_texte = scrolledtext.ScrolledText(
    contenu,
    wrap=tk.WORD,
    font=("Arial", 11),
    height=10
)
zone_texte.pack(
    fill=tk.BOTH,
    expand=True,
    padx=20,
    pady=8
)
zone_texte.bind("<ButtonRelease-1>", selectionner_fragment)

# Commandes de lecture des extraits audio
cadre_audio = tk.Frame(contenu)
cadre_audio.pack(pady=(5, 10))

bouton_ecouter = tk.Button(
    cadre_audio,
    text="Écouter l'extrait",
    command=ecouter_fragment,
    padx=15,
    pady=8
)
bouton_ecouter.pack(side=tk.LEFT, padx=5)

bouton_arreter = tk.Button(
    cadre_audio,
    text="Arrêter",
    command=arreter_fragment,
    padx=15,
    pady=8
)
bouton_arreter.pack(side=tk.LEFT, padx=5)


bouton_renommer = tk.Button(
    contenu,
    text="Renommer les interlocuteurs",
    command=ouvrir_fenetre_interlocuteurs,
    padx=15,
    pady=8
)
bouton_renommer.pack(pady=(5, 5))

cadre_sauvegarde = tk.Frame(contenu)
cadre_sauvegarde.pack(pady=(5, 10))

bouton_enregistrer = tk.Button(
    cadre_sauvegarde,
    text="Enregistrer en TXT",
    command=enregistrer_transcription,
    state="disabled",
    padx=15,
    pady=8
)
bouton_enregistrer.pack(side=tk.LEFT, padx=5)

bouton_guardar_reunion = tk.Button(
    cadre_sauvegarde,
    text="Enregistrer la réunion",
    command=enregistrer_reunion,
    padx=15,
    pady=8
)
bouton_guardar_reunion.pack(side=tk.LEFT, padx=5)

fenetre.after(500, verifier_evenements)

bouton_analyse_ia = tk.Button(
    contenu,
    text="Passer à l'analyse avec l'IA",
    command=passer_analyse_ia,
    padx=20,
    pady=10
)
bouton_analyse_ia.pack(pady=(5, 15))

fenetre.mainloop()
