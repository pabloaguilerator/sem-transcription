import re


def renombrar_interlocutores(texto, nombres):
    """Sustituye los identificadores de interlocutores al inicio de cada intervención."""
    patron = re.compile(r"(?m)^(SPEAKER_\d+)(?=\s+\[\d{2}:\d{2}\]\s*:)")

    return patron.sub(
        lambda coincidencia: nombres.get(
            coincidencia.group(1),
            coincidencia.group(1)
        ),
        texto
    )


if __name__ == "__main__":
    ejemplo = (
        "SPEAKER_00 [00:12] : Bonjour à tous.\n\n"
        "SPEAKER_01 [00:25] : Merci beaucoup.\n\n"
        "SPEAKER_00 [00:38] : Nous allons commencer."
    )

    nombres = {
        "SPEAKER_00": "Sophie",
        "SPEAKER_01": "Marc"
    }

    print(renombrar_interlocutores(ejemplo, nombres))
