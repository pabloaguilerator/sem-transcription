"""Exportation locale des résumés de réunions en PDF et Word."""

from datetime import datetime
from pathlib import Path
import re

from docx import Document
from docx.shared import Cm, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, KeepTogether
)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from xml.sax.saxutils import escape


DOSSIER_EXPORT = Path.home() / "Downloads"

POLICE = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
POLICE_GRAS = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"


def nom_fichier(titre, extension):
    """Construit un nom de fichier sûr et unique."""
    nom = re.sub(r"[^\w\- ]", "", titre, flags=re.UNICODE)
    nom = re.sub(r"\s+", "_", nom.strip())[:65] or "reunion"
    date = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    return f"{nom}_{date}.{extension}"


def preparer_destination(titre, extension):
    DOSSIER_EXPORT.mkdir(parents=True, exist_ok=True)
    return DOSSIER_EXPORT / nom_fichier(titre, extension)


def est_titre(ligne):
    """Détecte les rubriques courantes du résumé."""
    ligne = ligne.strip()
    rubriques = (
        "résumé général", "points abordés",
        "décisions prises", "actions à réaliser"
    )
    simplifie = re.sub(r"^\d+[\.\)\s-]*", "", ligne).lower()
    return simplifie.rstrip(":") in rubriques



def decorer_page_pdf(canvas, document):
    """Ajoute l'en-tête institutionnel et le numéro de page."""
    canvas.saveState()

    largeur, hauteur = A4

    canvas.setFont("SEMDejaVuBold", 9)
    canvas.setFillColor(colors.HexColor("#183153"))
    canvas.drawString(
        48, hauteur - 32,
        "COMPTE RENDU DE RÉUNION"
    )

    canvas.setStrokeColor(colors.HexColor("#D5DEE8"))
    canvas.setLineWidth(0.7)
    canvas.line(48, hauteur - 39, largeur - 48, hauteur - 39)

    canvas.line(48, 42, largeur - 48, 42)

    canvas.setFont("SEMDejaVu", 8)
    canvas.setFillColor(colors.HexColor("#666666"))
    canvas.drawRightString(
        largeur - 48, 29,
        f"Page {document.page}"
    )

    canvas.restoreState()


def exporter_pdf(titre, resume, date_enregistrement=''):
    """Génère un PDF A4 à partir du résumé corrigé."""
    if not resume.strip():
        raise ValueError("Le résumé est vide.")

    destination = preparer_destination(titre, "pdf")

    pdfmetrics.registerFont(TTFont("SEMDejaVu", POLICE))
    pdfmetrics.registerFont(TTFont("SEMDejaVuBold", POLICE_GRAS))

    styles = {
        "titre": ParagraphStyle(
            "SEMTitre",
            fontName="SEMDejaVuBold",
            fontSize=17,
            leading=24,
            textColor=colors.HexColor("#183153"),
            spaceAfter=15,
        ),
        "section": ParagraphStyle(
            "SEMSection",
            fontName="SEMDejaVuBold",
            fontSize=11,
            leading=17,
            spaceBefore=13,
            spaceAfter=6,
        ),
        "texte": ParagraphStyle(
            "SEMTexte",
            fontName="SEMDejaVu",
            fontSize=9.5,
            leading=15,
            spaceAfter=8,
        ),
    }

    document = SimpleDocTemplate(
        str(destination),
        pagesize=A4,
        rightMargin=48,
        leftMargin=48,
        topMargin=52,
        bottomMargin=52,
        title=titre,
    )

    date_formatee = (
        datetime.fromisoformat(date_enregistrement).strftime("%d/%m/%Y à %H:%M")
        if date_enregistrement else "Non renseignée"
    )

    elements = [
        Paragraph(escape(titre or "Réunion"), styles["titre"]),
        Paragraph(
            "Document exporté le "
            + datetime.now().strftime("%d/%m/%Y à %H:%M"),
            styles["texte"],
        ),
        Paragraph(
            "Date d'enregistrement : " + escape(date_formatee),
            styles["texte"]
        ),
        Spacer(1, 14),
    ]

    for ligne in resume.splitlines():
        ligne = ligne.strip()
        if not ligne:
            elements.append(Spacer(1, 5))
        elif est_titre(ligne):
            elements.append(
                Paragraph(escape(ligne), styles["section"])
            )
        else:
            elements.append(
                Paragraph(escape(ligne), styles["texte"])
            )

    document.build(
        elements,
        onFirstPage=decorer_page_pdf,
        onLaterPages=decorer_page_pdf
    )
    return destination


def exporter_word(titre, resume, date_enregistrement=''):
    """Génère un document Word A4 à partir du résumé corrigé."""
    if not resume.strip():
        raise ValueError("Le résumé est vide.")

    destination = preparer_destination(titre, "docx")
    document = Document()

    section = document.sections[0]
    section.page_width = Cm(21)
    section.page_height = Cm(29.7)
    section.top_margin = Cm(2.2)
    section.bottom_margin = Cm(2.2)
    section.left_margin = Cm(2.3)
    section.right_margin = Cm(2.3)

    # En-tête institutionnel
    en_tete = section.header
    paragraphe = en_tete.paragraphs[0]
    paragraphe.text = "COMPTE RENDU DE RÉUNION"
    paragraphe.style = document.styles["Normal"]

    texte = paragraphe.runs[0]
    texte.bold = True
    texte.font.name = "DejaVu Sans"
    texte.font.size = Pt(9)


    normal = document.styles["Normal"]
    normal.font.name = "DejaVu Sans"
    normal.font.size = Pt(10)

    # Styles professionnels
    style_titre = document.styles["Title"]
    style_titre.font.name = "DejaVu Sans"
    style_titre.font.size = Pt(17)
    style_titre.font.bold = True
    style_titre.font.color.rgb = RGBColor(24, 49, 83)

    style_section = document.styles["Heading 2"]
    style_section.font.name = "DejaVu Sans"
    style_section.font.size = Pt(11)
    style_section.font.bold = True
    style_section.font.color.rgb = RGBColor(24, 49, 83)
    style_section.paragraph_format.space_before = Pt(14)
    style_section.paragraph_format.space_after = Pt(6)

    normal.paragraph_format.space_after = Pt(7)

    document.add_heading(titre or "Réunion", level=0)
    date_formatee = (
        datetime.fromisoformat(date_enregistrement).strftime("%d/%m/%Y à %H:%M")
        if date_enregistrement else "Non renseignée"
    )
    document.add_paragraph("Date d'enregistrement : " + date_formatee)
    document.add_paragraph(
        "Document exporté le "
        + datetime.now().strftime("%d/%m/%Y à %H:%M")
    )

    for ligne in resume.splitlines():
        ligne = ligne.strip()
        if not ligne:
            continue
        if est_titre(ligne):
            document.add_heading(ligne, level=2)
        else:
            document.add_paragraph(ligne)

    # Pied de page avec numérotation automatique
    pied = section.footer.paragraphs[0]
    pied.alignment = WD_ALIGN_PARAGRAPH.RIGHT

    texte_page = pied.add_run("Page ")
    texte_page.font.name = "DejaVu Sans"
    texte_page.font.size = Pt(8)
    texte_page.font.color.rgb = RGBColor(102, 102, 102)

    champ = OxmlElement("w:fldSimple")
    champ.set(qn("w:instr"), "PAGE")
    pied._p.append(champ)

    document.save(destination)
    return destination
