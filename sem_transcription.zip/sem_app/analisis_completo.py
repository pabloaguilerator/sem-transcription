
"""Analyse progressive des réunions longues avec Qwen3 local."""

import json
import re
import urllib.request
from pathlib import Path

from resume_long import diviser_transcription, analyser_fragment


URL = "http://127.0.0.1:8080/v1/chat/completions"


def demander_ia(prompt, max_tokens=650):
    donnees = {
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": max_tokens,
        "temperature": 0.1,
    }

    requete = urllib.request.Request(
        URL,
        data=json.dumps(donnees).encode("utf-8"),
        headers={"Content-Type": "application/json"},
    )

    with urllib.request.urlopen(requete, timeout=900) as reponse:
        resultat = json.load(reponse)

    contenu = resultat["choices"][0]["message"]["content"].strip()

    if not contenu:
        raise RuntimeError("Qwen3 a renvoyé une réponse vide.")

    return contenu


def regrouper_textes(textes, taille_max=3500):
    groupes = []
    courant = ""

    for texte in textes:
        texte = texte.strip()

        if not texte:
            continue

        if len(texte) > taille_max:
            morceaux = [
                texte[i:i + taille_max]
                for i in range(0, len(texte), taille_max)
            ]
        else:
            morceaux = [texte]

        for morceau in morceaux:
            if courant and len(courant) + len(morceau) + 2 > taille_max:
                groupes.append(courant)
                courant = ""

            courant += ("\n\n" if courant else "") + morceau

    if courant:
        groupes.append(courant)

    return groupes


def generer_analyse_complete(transcription, progression=None,
                             dossier_sauvegarde=None):
    fragments = diviser_transcription(transcription, taille_max=1500)

    if not fragments:
        raise ValueError("La transcription est vide.")

    dossier = Path(
        dossier_sauvegarde or
        Path.home() / "projet_transcription" / "analyses_partielles"
    )
    dossier.mkdir(parents=True, exist_ok=True)

    import hashlib
    identifiant = hashlib.sha256(
        transcription.encode("utf-8")
    ).hexdigest()[:16]

    fichier = dossier / f"analyse_{identifiant}.json"

    resultats = {}

    if fichier.exists():
        try:
            anciens = json.loads(fichier.read_text(encoding="utf-8"))
            if isinstance(anciens, dict):
                resultats = anciens
        except (OSError, ValueError):
            pass

    for numero, fragment in enumerate(fragments, start=1):
        cle = fragment["id"]

        if progression:
            progression(f"Analyse du fragment {numero}/{len(fragments)}")

        if cle in resultats and resultats[cle].strip():
            continue

        # Un fragment défaillant reste récupérable lors d'une relance.
        resultat = analyser_fragment(fragment, memoire="")
        resultats[cle] = resultat["analyse"]

        fichier.write_text(
            json.dumps(resultats, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    analyses = [
        f"{fragment['id']} :\n{resultats[fragment['id']]}"
        for fragment in fragments
    ]

    # Synthèses intermédiaires : aucun envoi du texte complet.
    niveau = 0

    while len(regrouper_textes(analyses, 3500)) > 1:
        if nivel_maximo_alcanzado := (nivel >= 4):
            raise RuntimeError(
                "Limite de 4 niveaux atteinte. "
                "Les analyses partielles sont conservées."
            )
        niveau += 1
        groupes = regrouper_textes(analyses, 3500)
        nouvelles_analyses = []

        for numero, groupe in enumerate(groupes, start=1):
            if progression:
                progression(
                    f"Synthèse niveau {niveau} : "
                    f"{numero}/{len(groupes)}"
                )

            prompt = (
                "Tu réunis des analyses de fragments d'une réunion. "
                "Rédige une synthèse fidèle et concise en français. "
                "Conserve les sujets, décisions confirmées, actions, "
                "responsables, échéances, désaccords et rectifications. "
                "Ne transforme jamais une proposition en décision. "
                "N'invente rien.\n\n"
                + groupe
            )

            nouvelles_analyses.append(
                demander_ia(
                    prompt + (
                        "\n\nRéponds en 120 mots maximum. "
                        "Conserve uniquement les informations essentielles. "
                        "Privilégie les décisions, actions, responsables "
                        "et échéances confirmées. "
                        "Signale les points non résolus."
                    ),
                    max_tokens=180
                )
            )

        analyses = nouvelles_analyses

    if progression:
        progression("Rédaction du résumé final...")

    prompt_final = (
        "À partir des notes suivantes, rédige le compte rendu "
        "de la réunion en français.\n\n"
        "Structure :\n"
        "1. Résumé général\n"
        "2. Points abordés\n"
        "3. Décisions confirmées\n"
        "4. Actions à réaliser (responsables et échéances si connus)\n"
        "5. Points restant à clarifier\n\n"
        "Distingue les propositions des décisions. "
        "N'invente aucune information.\n\n"
        + "\n\n".join(analyses)
    )

    resume = demander_ia(prompt_final, max_tokens=850)

    (dossier / f"resume_{identifiant}.txt").write_text(
        resume, encoding="utf-8"
    )

    if progression:
        progression("Résumé terminé.")

    return resume
