import os
import sys
import time
from pathlib import Path

os.environ["HF_HUB_OFFLINE"] = "1"

import torch
import soundfile as sf
from pyannote.audio import Pipeline


def diariser(fichier_audio, fichier_sortie):
    print("Chargement de l'audio...", flush=True)

    audio, frequence = sf.read(
        fichier_audio,
        dtype="float32",
        always_2d=True
    )

    waveform = torch.from_numpy(audio.T.copy())

    print("Chargement du modèle pyannote...", flush=True)

    pipeline = Pipeline.from_pretrained(
        "pyannote/speaker-diarization-community-1"
    )
    pipeline.to(torch.device("cpu"))

    print("Identification des interlocuteurs...", flush=True)

    debut = time.perf_counter()

    resultat = pipeline({
        "waveform": waveform,
        "sample_rate": frequence
    })

    duree = time.perf_counter() - debut

    lignes = []
    locuteurs = set()

    for segment, _, locuteur in (
        resultat.speaker_diarization.itertracks(yield_label=True)
    ):
        locuteurs.add(locuteur)
        lignes.append(
            f"{segment.start:.2f} - {segment.end:.2f} | {locuteur}"
        )

    Path(fichier_sortie).write_text(
        "\n".join(lignes),
        encoding="utf-8"
    )

    print(f"Interlocuteurs détectés : {len(locuteurs)}", flush=True)
    print(f"Durée de diarisation : {duree:.1f} secondes", flush=True)
    print(f"Résultat : {fichier_sortie}", flush=True)


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print(
            "Usage : diarisation_auto.py audio.wav resultat.txt",
            file=sys.stderr
        )
        sys.exit(1)

    diariser(sys.argv[1], sys.argv[2])
